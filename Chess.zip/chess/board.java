/*
 * Copyright (c) 2023 Leonel Benítez
 * This work is licensed under CC BY-NC-SA 4.0 
 * See the LICENSE.txt file for details.
 */

package chess;

import pieces.*;

import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;


public class board extends JPanel{

    public int titleSize = 100;
    ;
    int cols = 8;
    int rows = 8;

    int col;
    int row;

    int checkCol;
    int checkRow;
    public boolean check = false;

    public boolean isWhiteTurn = true;

    ArrayList<Piece> pieceList = new ArrayList<>();
    ArrayList<Piece> whiteMovesList = new ArrayList<>();
    ArrayList<Piece> blackMovesList = new ArrayList<>();

    int blackWins = 0;
    int blackWinsAccumulator;
    int whiteWins = 0;
    int whiteWinsAccumulator;
    
    public Piece pieceWithCollide;
    public Piece selectedPiece;

    Piece p;

    Input input = new Input(this);

    public CheckScanner checkScanner = new CheckScanner(this);

    public int enPassantTile = -1;
    
     public void resetGame() {
        check = false;
        pieceList.clear();
        enPassantTile = -1;
        isWhiteTurn = true;
        input.isCheckMate = false;
        p = null;

        whiteWinsAccumulator = whiteWins;
        blackWinsAccumulator = blackWins;
        
        paintTrackWins(blackWins, whiteWins);
        addPieces();
        repaint();
    }

    Chess chessBoard;
    Players players;

    public board(Chess chessBoard){
        
        this.chessBoard = chessBoard;

        this.setPreferredSize(new Dimension((cols*titleSize), (rows*titleSize)));

        this.addMouseListener(input);
        this.addMouseMotionListener(input);
        
        panelsTurn(false,chessBoard.whitesName,chessBoard.blacksName);
        paintTrackWins(blackWins, whiteWins);
        addPieces();
    }
    
    public void makeMove(Move move) {
        if (move.piece.name.equals("Pawn")){
            movePawn(move);
        } else if (move.piece.name.equals("King")) {
            moveKing(move);
        }
        move.piece.col = move.newCol;
        move.piece.row = move.newRow;
        move.piece.xPos = move.newCol * titleSize;
        move.piece.yPos = move.newRow * titleSize;
    
        move.piece.isFirstMove = false;
    
        capture(move.capture);
        
        panelsTurn(isWhiteTurn,chessBoard.whitesName,chessBoard.blacksName);
    }

    private void panelsTurn(boolean isWhiteTurn,JTextArea whiteTextArea, JTextArea blackTextArea) {
        if (!isWhiteTurn) {
            whiteTextArea.setBackground(new Color(16, 99, 9, 170));
            blackTextArea.setBackground(new Color(28, 27, 23));
        } else {
            blackTextArea.setBackground(new Color(16, 99, 9, 170));
            whiteTextArea.setBackground(new Color(28, 27, 23));
        }
    }

    public void paintTrackWins(int whiteWins, int blackWins) {
        chessBoard.trackWins.removeAll();
        for (int i = 0; i < 22; i++) {
            JLabel label = new JLabel();
            label.setHorizontalAlignment(JLabel.CENTER);
            label.setBorder(BorderFactory.createLineBorder(new Color(97,97,97,150)));
            
            if (i == 10) {
                label.setForeground(Color.WHITE);
                label.setText("B");
            } else if (i==21) {
                label.setForeground(Color.WHITE);
                label.setText("W");
            
            }
            else if (i<10) {
                if (whiteWins <= 0) {
                    label.setText(String.valueOf(0));
                } else {
                    label.setForeground(Color.WHITE);
                    label.setText(String.valueOf(1));
                    whiteWins--;
                }
            } else if (i>10 && i<21) {
                if (blackWins <= 0) {
                    label.setText(String.valueOf(0));
                } else {
                    label.setForeground(Color.WHITE);
                    label.setText(String.valueOf(1));
                    blackWins--;
                }
            }

            chessBoard.trackWins.add(label);
            chessBoard.trackWins.revalidate();
            chessBoard.trackWins.repaint(); 
        }

    }

    public Piece getPiece(int col, int row) {
        for(Piece piece : pieceList) {

            if (piece.col == col && piece.row == row) {
                return piece;
            }
        }
        return null;
    }
    
    public void moves() {
            whiteMovesList.clear();
            blackMovesList.clear();
            for (Piece piece : pieceList) { 
                for(int r = 0; r < 8; r++) 
                for (int c = 0; c < 8; c++) {
                    if (piece.isValidMovement(c, r) && isValidMove(new Move(this, piece, c, r))) {
                        if (piece.isWhite) {
                            whiteMovesList.add(piece);
                        } else {
                            blackMovesList.add(piece);
                        }
                    }
                }
        }
        
        int w = 1;
        int w1 = 0;
        for (Piece piece2 : whiteMovesList) {
            if (w>w1) {
                w1 = w;
            } 
            w++;
        }
        int b = 1;
        int b1 = 1;
        for (Piece piece2 : blackMovesList) {
            if (b>b1) {
                b1 = b;
            }
            b++;
        }
    }
    
    private void moveKing(Move move) {
        if (Math.abs(move.piece.col - move.newCol) == 2) {
            Piece rook;
            if (move.piece.col < move.newCol) {
                rook = getPiece(7, move.piece.row);
                rook.col = 5;
            } else {
                rook = getPiece(0, move.piece.row);
                rook.col = 3;
            }
            rook.xPos = rook.col * titleSize;
        }
    }

    private void movePawn(Move move) {

        //en passant
        int colorIndex = move.piece.isWhite ? 1 : -1;

        if (getTileNum(move.newCol, move.newRow) == enPassantTile) {
            move.capture = getPiece(move.newCol, move.newRow + colorIndex);
        }
        if (Math.abs(move.piece.row - move.newRow) == 2) {
            enPassantTile = getTileNum(move.newCol, move.newRow + colorIndex);
        } else {
            enPassantTile = -1;
        }


        //Promotions
        colorIndex = move.piece.isWhite ? 0 : 7;
        if (move.newRow == colorIndex) {
            promotePawn(move);
        }
    }

    public void promotePawn(Move move) {
        pieceList.add(new Queen(this, move.newCol, move.newRow, move.piece.isWhite));
        capture(move.piece);
    }

    public void capture(Piece piece) {
         pieceList.remove(piece);
    }

    public boolean captureKing(Piece p2){
        if (p2 == null) {
            return false;
        }
        return p2.name.equals("King");
    }

    public boolean isValidMove(Move move) {

        if(captureKing(move.capture)) {
            return false;
        }

        if (sameTeam(move.piece, move.capture)) {    
            return false;
        }

        pieceWithCollide = getPiece(move.newCol, move.newRow);

        if (!move.piece.isValidMovement(move.newCol, move.newRow)) {
             return false;
        }

        if (move.piece.moveCollidesWithPiece(move.newCol, move.newRow)) {
            return false;
        }
        if (checkScanner.isKingCheckedByKing(move)) {
            return false;
        }

        if (checkScanner.isKingChecked(move)) {
                check = true;
                if (isWhiteTurn) {
                    
                    if (whiteMovesList.size() == 1) {
                        p = whiteMovesList.get(0);
                        if (p.name.equals("King")) {
                            input.isCheckMate = true;
                        }
                    }
                } else { 
                    if (blackMovesList.size() == 1) {
                        p = blackMovesList.get(0);
                        if (p.name.equals("King")) {
                            input.isCheckMate = true;
                        }
                    }

                }
                
            return false;
        }
        check = false;
        repaint();
        return true;
    }

    public boolean sameTeam(Piece p1, Piece p2) {
        if (p1 == null || p2 == null) {
            return false;
        }
        return p1.isWhite == p2.isWhite;
    }

    public int getTileNum(int col, int row) { return row * rows + col;}

    Piece findKing(boolean isWhite) {
        for (Piece piece : pieceList){
            if ((isWhite == piece.isWhite) && piece.name.equals("King")) {
                checkCol = piece.col;
                checkRow = piece.row;
                return piece;
            }
        }
        return null;
    }

    public void addPieces() {
        //Black pieces
        pieceList.add(new Pawn(this, 0, 1, false));
        pieceList.add(new Pawn(this, 1, 1, false));
        pieceList.add(new Pawn(this, 2, 1, false));
        pieceList.add(new Pawn(this, 3, 1, false));
        pieceList.add(new Pawn(this, 4, 1, false));
        pieceList.add(new Pawn(this, 5, 1, false));
        pieceList.add(new Pawn(this, 6, 1, false));
        pieceList.add(new Pawn(this, 7, 1, false));
        pieceList.add(new Knight(this, 1, 0, false));
        pieceList.add(new Knight(this, 6, 0, false));
        pieceList.add(new Rook(this, 0, 0, false));
        pieceList.add(new Rook(this, 7, 0, false));
        pieceList.add(new Bishop(this, 2, 0, false));
        pieceList.add(new Bishop(this, 5, 0, false));
        pieceList.add(new Queen(this, 3, 0, false));
        pieceList.add(new King(this, 4, 0, false));
        //White pieces
        pieceList.add(new Pawn(this, 0, 6, true));
        pieceList.add(new Pawn(this, 1, 6, true));
        pieceList.add(new Pawn(this, 2, 6, true));
        pieceList.add(new Pawn(this, 3, 6, true));
        pieceList.add(new Pawn(this, 4, 6, true));
        pieceList.add(new Pawn(this, 5, 6, true));
        pieceList.add(new Pawn(this, 6, 6, true));
        pieceList.add(new Pawn(this, 7, 6, true));
        pieceList.add(new Knight(this, 1, 7, true));
        pieceList.add(new Knight(this, 6, 7, true));
        pieceList.add(new Rook(this, 0, 7, true));
        pieceList.add(new Rook(this, 7, 7, true));
        pieceList.add(new Bishop(this, 2, 7, true));
        pieceList.add(new Bishop(this, 5, 7, true));
        pieceList.add(new Queen(this, 3, 7, true));
        pieceList.add(new King(this, 4, 7, true));
    }

    /* To paint on de board */
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;

        // board squares
        for (int r = 0; r < rows; r++) 
        for (int c = 0; c < cols; c++) {
            g2d.setColor((c+r) % 2 == 0 ? new Color(240, 217, 181) : new Color(157, 105, 53));
            g2d.fillRect(c * titleSize, r * titleSize, titleSize, titleSize);
            
        }
        
        for (int b = 8; b>-1; b--){
            g2d.setColor((7+b) % 2 == 0 ? new Color(240, 217, 181) : new Color(157, 105, 53));
            g2d.drawString(String.valueOf(b+1), 7 * titleSize + titleSize - 7, (8-b) * titleSize - titleSize*6/7);
        }
        
        for (int a = 0; a<8; a++){
            String[] letters = {"a", "b", "c", "d", "e", "f", "g", "h"};
            g2d.setColor((7+a) % 2 == 0 ?  new Color(157, 105, 53) : new Color(240, 217, 181));
            g2d.drawString(letters[a], (a+1) * titleSize - titleSize, 7 * titleSize + titleSize - 7/3);
        }

        // highlight squares available
        if (selectedPiece != null) {
            for (int r = 0; r < rows; r++) 
            for (int c = 0; c < cols; c++) {
                
                
                if (isValidMove(new Move(this, selectedPiece, c, r))) {
                    g2d.setColor(new Color(16,99,9,170));
                    g2d.fillOval(c * titleSize + titleSize / 3, r * titleSize + titleSize / 3, titleSize / 3, titleSize / 3);
                    
                    if (pieceWithCollide != null) {
                        g2d.setColor(new Color(94,135,71,200));
                        g2d.fillRect(pieceWithCollide.col * titleSize, pieceWithCollide.row * titleSize, titleSize, titleSize);
                        g2d.setColor((pieceWithCollide.col+pieceWithCollide.row) % 2 == 0 ? new Color(240, 217, 181) : new Color(157, 105, 53));
                        g2d.fillOval(pieceWithCollide.col * titleSize, pieceWithCollide.row * titleSize, titleSize, titleSize);
                    }
                }

                g2d.setColor(new Color(94,135,71,150));
                g2d.fillRect(selectedPiece.col * titleSize, selectedPiece.row * titleSize, titleSize, titleSize);
            }
            
        }
        if (check) {
            g2d.setColor(new Color(234,76,63,180));
            g2d.fillOval(checkCol * titleSize, checkRow * titleSize, titleSize, titleSize);
            g2d.setColor(new Color(233,45,37,160));
            g2d.fillOval(checkCol * titleSize + titleSize/14, checkRow * titleSize + titleSize/14, titleSize*7/8, titleSize*7/8);
        }

        if (!check){
                check = false;
        }

        //pieces
        for(Piece piece : pieceList){
            piece.paint(g2d);
        }
        
    }
}