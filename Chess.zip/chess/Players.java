/*
 * Copyright (c) 2023 Leonel Benítez
 * This work is licensed under CC BY-NC-SA 4.0 
 * See the LICENSE.txt file for details.
 */

package chess;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;


public class Players extends JFrame {

     public Chess newChess;

    JTextField player = new JTextField();

    JLabel text;
    
    boolean firstPlayerEntered = false;
    boolean secondPlayerEntered = false;

    public static String player1;
    public static String player2;

    public Players() {
        createGUI();
    }

    private void createGUI() {
        setUndecorated(true);

        Container windowContainer = getContentPane();
        windowContainer.setBackground(new Color(22, 21, 18));
        setMinimumSize(new Dimension(500, 300));
        setLocationRelativeTo(null);
        windowContainer.setLayout(null);

        text = new JLabel();
        text.setText("<html> <br> First Player: </html>");
        text.setFont(new Font("Serif", Font.BOLD, 38));
        text.setForeground(Color.white);
        text.setBounds(150, 30, 500, 90);

        windowContainer.add(text);

        // Add a placeholder to player JTextField
        player.setText("Enter NickName");
        player.setForeground(Color.gray);
        player.setFont(new Font("Serif", Font.BOLD, 30));
        player.setBackground(new Color(28, 27, 23));
        player.setBounds(100, 150, 300, 60);
        windowContainer.add(player);
        player.addMouseListener(mouseListener);
        player.addKeyListener(keyListener);

    }

    MouseListener mouseListener = new MouseListener() {

        @Override
        public void mouseEntered(MouseEvent evt) {
            if (player.getText().equals("")) {
                player.setForeground(Color.gray);
                player.setText("Enter NickName");
            }
        }

        @Override
        public void mouseExited(MouseEvent evt) {
            if (player.getText().equals("")) {
                player.setForeground(Color.gray);
                player.setText("Enter NickName");
            }
        }

        @Override
        public void mouseClicked(MouseEvent evt) {}

        @Override
        public void mousePressed(MouseEvent evt) {
            if (player.getText().equals("Enter NickName")) {
                player.setText("");
            }
        }

        @Override
        public void mouseReleased(MouseEvent evt) {}
    };

    KeyListener keyListener = new KeyListener() {
        @Override
        public void keyTyped (KeyEvent ke){
            player.setForeground(Color.white);
        } 
        @Override
        public void keyPressed (KeyEvent ke){
            if (player.getText().equals("Enter NickName")) {
                player.setText("");
            }
        } 

        @Override
        public void keyReleased (KeyEvent ke){
            
            if (ke.getKeyCode() == KeyEvent.VK_ENTER) {
                if ((!player.getText().equals("") && (!player.getText().equals("Enter NickName")))) {
                    if (!firstPlayerEntered) {
                        player1 = player.getText();
                        text.setText("<html><br> Second Player: </html>");
                        firstPlayerEntered = true;
                        player.setText("");
                    } else {
                        if (!secondPlayerEntered) {
                            player2 = player.getText();
                            secondPlayerEntered = true;
                            dispose();
                            SwingUtilities.invokeLater(() -> {  
                                newChess = new Chess();
                                newChess.setVisible(true);
                            });
                        }
                    }
                }
            }
        } 
    };
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Players players = new Players();
            players.setVisible(true);
        });
    }
}
