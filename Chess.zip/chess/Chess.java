/*
 * Copyright (c) 2023 Leonel Benítez
 * This work is licensed under CC BY-NC-SA 4.0 
 * See the LICENSE.txt file for details.
 */

package chess;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Chess extends JFrame implements ActionListener{
    Players player;
    
    JButton closeWindow = new JButton();
    JButton openRights = new JButton();
    
    int frameWidth;
    int frameHeight;
    
    JTextArea blacksName= new JTextArea();
    JTextArea whitesName= new JTextArea();

    JPanel rightsPanel= new JPanel();
    JPanel trackWins = new JPanel();
    JPanel closeButton = new JPanel() {
    @Override
    protected void paintComponent(Graphics g) {
        
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(new Color(97,97,97,150));
        g2d.fillOval(getWidth() / 2 - getWidth() / 10, getHeight()/2 - getHeight() / 10, getWidth() / 5, getHeight() / 5);
        
        float strokeWidth = (float) getWidth()*3/2 / 26.0f;
        g2d.setStroke(new BasicStroke(strokeWidth));
        g2d.drawLine(getWidth() / 8, getHeight() / 8, getWidth() / 2 - getWidth() / 8, getHeight()/2 - getHeight() / 8);
        g2d.drawLine(getWidth()/2 + getWidth() / 8,  getHeight()/2 - getHeight() / 8, getWidth() - getWidth() / 8, getHeight() / 8);
        g2d.drawLine(getWidth() / 8, getHeight() - getHeight() / 8, getWidth() / 2 - getWidth() / 8, getHeight()/2 + getHeight() / 8);
        g2d.drawLine(getWidth()/2 + getWidth() / 8, getHeight()/2 + getHeight() / 8, getWidth() - getWidth() / 8, getHeight() - getHeight() / 8);
    }
    };

    Cursor handCursor = Cursor.getPredefinedCursor(Cursor.HAND_CURSOR);

    public Chess() {
        letsPlay();
    }
    
    private void letsPlay () {
        setUndecorated(true);
        
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice[] screens = ge.getScreenDevices();
        DisplayMode mode = screens[0].getDisplayMode();
        setSize(mode.getWidth(), mode.getHeight());
        frameWidth = (int) mode.getWidth();
        frameHeight = (int) mode.getHeight();
        
        getContentPane().setBackground(new Color(22, 21, 18));
        getContentPane().add(closeWindow);
        
        getContentPane().setLayout(null);
        board board = new board(this);
        
        closeButton.setBackground(new Color(28, 27, 23));
        
        closeWindow.setBounds(frameWidth - board.titleSize*2/3, 0, board.titleSize*2/3, board.titleSize*2/3);
        closeWindow.add(closeButton);
        configureImageButton(closeWindow);
        closeWindow.addActionListener(this);
        
        rightsPanel.setBackground(new Color(28, 27, 23));

        openRights.setBounds(frameWidth - board.titleSize*4/3, frameHeight -  board.titleSize*2/3, board.titleSize*4/3, board.titleSize*2/3);
        openRights.addActionListener(this);
        configureImageButton(openRights);
        openRights.add(rightsPanel);
        getContentPane().add(openRights);
        
        board.setCursor(handCursor);
        board.setBounds(board.titleSize*3/2, board.titleSize - board.titleSize/4, board.titleSize * 8, board.titleSize * 8);
        getContentPane().add(board);
        

        blacksName.setBounds(board.titleSize*10 + board.titleSize*1/3, board.titleSize*7/2, 3*board.titleSize, board.titleSize*4/5);
        blacksName.setForeground(Color.white);
        blacksName.setFont(new Font("Serif", Font.BOLD, board.titleSize*6/10));
        blacksName.setText(player.player1);
        getContentPane().add(blacksName);
        
        whitesName.setBounds(board.titleSize*10 + board.titleSize*1/3, board.titleSize*13/2, 3*board.titleSize, board.titleSize*4/5);
        whitesName.setForeground(Color.white);
        whitesName.setFont(new Font("Serif", Font.BOLD, board.titleSize*6/10));
        whitesName.setText(player.player2);
        getContentPane().add(whitesName);

        trackWins.setLayout(new GridLayout(2,11));
        trackWins.setBounds(board.titleSize*3, board.titleSize * 9 + 1/2 *board.titleSize, board.titleSize * 4, board.titleSize/2);
        trackWins.setBackground(new Color(28, 27, 23));
        getContentPane().add(trackWins);

    }

   @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(closeWindow)) {
            SwingUtilities.invokeLater(()-> {
                ExitOperation exitOperation = new ExitOperation();
                exitOperation.setVisible(true);
            });
        } else if (e.getSource().equals(openRights)) {
            
                SwingUtilities.invokeLater(()-> {
                    Rights rights = new Rights();
                    rights.setVisible(true);
                });
            
        }
        
    }
    
    
    public void configureImageButton(JButton button) {
        button.setBorderPainted(true);
        button.setFocusPainted(false);
        button.setOpaque(false);
        button.setBorder(null); 
        Cursor handCursor = Cursor.getPredefinedCursor(Cursor.HAND_CURSOR);
        button.setCursor(handCursor);
    }
}
