/*
 * Copyright (c) 2023 Leonel Benítez
 * This work is licensed under CC BY-NC-SA 4.0 
 * See the LICENSE.txt file for details.
 */

package chess;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingUtilities;

public class Input extends MouseAdapter {

    public board board;
    CheckScanner checkScanner;

    public Input(board board) {
        this.board = board;
    }

    int col;
    int row;

    public boolean isCheckMate;

    @Override
    public void mousePressed(MouseEvent e) {

         col = e.getX() / board.titleSize;
         row = e.getY() / board.titleSize;
        
        
        if (board.getPiece(col, row) != null) {
            if (board.getPiece(col, row).isWhite && board.isWhiteTurn) {
                board.selectedPiece = board.getPiece(col, row);
            } else if (!board.getPiece(col, row).isWhite && !board.isWhiteTurn) {
                board.selectedPiece = board.getPiece(col, row);
            }
        }
    }
    
        @Override
        public void mouseDragged(MouseEvent e) {
            if (board.selectedPiece != null) {
                
                board.selectedPiece.xPos = e.getX() - board.titleSize / 2;
                board.selectedPiece.yPos = e.getY() - board.titleSize / 2;

                if (board.check) {
                    board.moves();
                }

                board.repaint();
            }
        }
    
    @Override
    public void mouseReleased(MouseEvent e) {
        
         col = e.getX() / board.titleSize;
         row = e.getY() / board.titleSize;

        if (board.selectedPiece != null) {

            Move move = new Move(board, board.selectedPiece, col, row);
            
            if (board.isValidMove(move)) {

                board.makeMove(move);
                board.moves();
                
                board.isWhiteTurn = !board.isWhiteTurn;
                
            } else {
                board.selectedPiece.xPos = board.selectedPiece.col * board.titleSize;
                board.selectedPiece.yPos = board.selectedPiece.row * board.titleSize;

            }
            if (isCheckMate) {
                if (!board.isWhiteTurn) {
                    SwingUtilities.invokeLater(() -> {  
                            CheckMate endGame = new CheckMate(board.isWhiteTurn, board);
                            endGame.setVisible(true);
                        });
                } else {
                    SwingUtilities.invokeLater(() -> {  
                            CheckMate endGame = new CheckMate(board.isWhiteTurn, board);
                            endGame.setVisible(true);
                        });
                }
            }
            
        }
        board.selectedPiece = null;
        board.repaint();
    }

}
