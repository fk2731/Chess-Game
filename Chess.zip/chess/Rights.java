/*
 * Copyright (c) 2023 Leonel Benítez
 * This work is licensed under CC BY-NC-SA 4.0 
 * See the LICENSE.txt file for details.
 */

package chess;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JWindow;

import java.awt.*;
import java.awt.event.*;

public class Rights extends JWindow {
    Chess chess = new Chess();

    JButton closeButton = new JButton();

    JLabel rights= new JLabel();
    public void showRights() {

        Container windowContainer = getContentPane();
        windowContainer.setBackground(new Color(28, 27, 23));
        setLocationRelativeTo(null);
        FlowLayout layout = new FlowLayout();
        layout.setAlignment(FlowLayout.LEFT);
        layout.setHgap(20);
        layout.setVgap(40);
        windowContainer.setLayout(layout);
  
        setSize(240, 230);
        
        Font font = new Font("Arial", Font.ITALIC, 12);
        rights.setForeground(Color.white);
        rights.setText("<html><center> Escuela Nacional Preparatoria No.6 <br> 'Antonio Caso' <br><br> Ben&iacute;tez P&eacute;rez Kristian Leonel <br><br> Adriana Vega Palos <br><br> Estudio Tecnico Especializado <br> en Computaci&oacute;n <br> Segundo a&ntilde;o <br><br> 2023-2024 </center></html>");
        rights.setFont(font);
        rights.addMouseListener(mouseListener);
        windowContainer.add(rights);
        windowContainer.addMouseListener(mouseListener);
    }
    
    MouseListener mouseListener = new MouseListener() {

        @Override
        public void mouseEntered(MouseEvent evt) {}

        @Override
        public void mouseExited(MouseEvent evt) {}

        @Override
        public void mouseClicked(MouseEvent evt) {dispose();}

        @Override
        public void mousePressed(MouseEvent evt) {}

        @Override
        public void mouseReleased(MouseEvent evt) {}
    };

    public Rights() {
            showRights();
    }

}
