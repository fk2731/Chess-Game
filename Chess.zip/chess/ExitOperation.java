/*
 * Copyright (c) 2023 Leonel Benítez
 * This work is licensed under CC BY-NC-SA 4.0 
 * See the LICENSE.txt file for details.
 */

package chess;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class ExitOperation extends JWindow implements ActionListener{
 
    JLabel text;
    JButton missClick;
    JButton clButton;

    public ExitOperation() {
        crearGUI();
    }

    private void crearGUI() {

        Container windowContainer = getContentPane();
        windowContainer.setBackground(new Color(22, 21, 18));
        setMinimumSize(new Dimension(500, 300));
        setLocationRelativeTo(null);

        windowContainer.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
    
        text= new JLabel();
            text.setText("<html> <center> Desea cerrar <br> la pestaña </center> </html>");
            text.setFont(new Font("Serief",Font.BOLD,35));
            text.setForeground(Color.white);

        missClick = new JButton();
            missClick.setBackground(new Color(22, 23, 18));
            configureImageButton(missClick);
            missClick.setText("Quedarse");
            missClick.setFont(new Font("Serief",Font.BOLD,25));
            missClick.setForeground(Color.white);
            missClick.addActionListener(this);
            missClick.addMouseListener(mouseListener);

        clButton = new JButton();
            clButton.setBackground(new Color(22, 23, 18));
            configureImageButton(clButton);
            clButton.setText("Salir");
            clButton.setFont(new Font("Serief",Font.BOLD,25));
            clButton.setForeground(Color.white);    
            clButton.addActionListener(this);
            clButton.addMouseListener(mouseListener);


        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.gridheight = 1;
        gbc.weightx = 1;
        gbc.weighty = .55;
        gbc.fill = GridBagConstraints.CENTER;
        add(text, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weighty = .25;
        gbc.fill = GridBagConstraints.BOTH;
        add(missClick, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weighty = .25;
        gbc.fill = GridBagConstraints.BOTH;
        add(clButton, gbc);
    }

    private void configureImageButton(JButton button) {
        button.setBorderPainted(true);
        button.setBorder(null); 
        Cursor handCursor = Cursor.getPredefinedCursor(Cursor.HAND_CURSOR);
        button.setCursor(handCursor);
    }

    JButton lastSourceButton;
    boolean firstEntry = true;
    
    MouseListener mouseListener = new MouseListener() {

        @Override
        public void mouseEntered(MouseEvent evt) {
            JButton sourceButton = (JButton) evt.getSource();
            repaint();
            sourceButton.setBackground(new Color(16, 99, 9, 170));
        }

        @Override
        public void mouseExited(MouseEvent evt) {
            JButton sourceButton = (JButton) evt.getSource();
            sourceButton.setBackground(new Color(22, 23, 18));
        }

        @Override
        public void mouseClicked(MouseEvent evt) {}

        @Override
        public void mousePressed(MouseEvent evt) {}

        @Override
        public void mouseReleased(MouseEvent evt) {}
    };

    @Override
    public void actionPerformed(ActionEvent e){
        Object action = e.getSource();

        if (action == missClick) {
                dispose();
        } else {
            System.exit(0);
        }
    }

}